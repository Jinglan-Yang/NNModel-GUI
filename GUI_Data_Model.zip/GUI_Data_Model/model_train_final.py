# coding:utf-8
##*******************************************************************//
##*            PKU PHIMO-ANN model (Training/model_train)           *//
##*******************************************************************//

## ******************************************************************//
## * Copyright 2023 Peking University, Shenzhen. All rights reserved  //
## *               
## * Project Director: Prof. Lining Zhang                            //
## * Authors: Wu Dai, Yu Li.//
## * Notes: This version is used to show the fitting ability of NN model.     //
## * The target is y = 2*sin(x) + 1                                 //
## *****************************************************************//
import torch
import numpy
import numpy as np
import math
import matplotlib.pyplot as plt
from numpy import genfromtxt
from model_framework import MLPregression

# num_epochs = 1000000
num_epochs = 50000

#################### Data processing #############################################################
file_container='/Users/yangjinglan/Desktop/interface_built'
handle=open(file_container+'/Training_DATA.txt',mode='r',encoding='utf-8')
title=handle.readlines(1)
variable_names=title[0].split()
print(variable_names)
lines=handle.read()[1:]
handle.close()
handle=open(file_container+'/Training_DATA_noTitle.txt',mode='w',encoding='utf-8')
handle.write(lines)
handle.close()
Training_data = genfromtxt(file_container+'/Training_DATA_noTitle.txt', encoding='utf-8-sig', delimiter="", dtype=float)
variableName_x='a'
variableName_y='b'
y_array = Training_data[:, variable_names.index(variableName_y)].reshape(Training_data.shape[0], 1)
x_input = Training_data[:, variable_names.index(variableName_x)].reshape(Training_data.shape[0], 1)
###################  MinMax Normalization  #############################################################
y_max = np.max(y_array)
y_min = np.min(y_array)
y_target_0 = np.zeros([Training_data.shape[0], 1])
for i in range(Training_data.shape[0]):
    y_target_0[i, 0] = ((y_array[i, 0] - y_min) / (y_max - y_min)) * (1 - (-1)) - 1
# y_target = torch.from_numpy(y_target_0).cuda().to(torch.float32).requires_grad_(requires_grad=True)
y_target = torch.from_numpy(y_target_0).to(torch.float32).requires_grad_(requires_grad=True)
###################  Import model framework  #############################################################
model=MLPregression()
###################  Optimizer selection  #############################################################
optimizer = torch.optim.Adam(model.parameters(), lr=1e-1, weight_decay=1e-8)
scheduler_lr = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.6, mode="min", patience=350,
                                                          threshold=1e-3, cooldown=350,
                                                          min_lr=1e-10, verbose=True)
###################  Define Loss function  #############################################################
def my_mse_loss(x1, y1):
    z1 = (y1 - x1)
    # loss = 1.0*torch.mean(torch.pow(z1, 2)).cuda()
    loss = 1.0*torch.mean(torch.pow(z1, 2))
    return loss
loss = numpy.zeros([num_epochs, 1])
###################  Define training process  #############################################################
def train():
    for epoch in range(num_epochs):
        y_hat = model(x_input)
        l = my_mse_loss(y_hat, y_target)
        optimizer.zero_grad()
        l.backward()
        optimizer.step()
        scheduler_lr.step(l)
        loss[epoch, 0] = l
        if (epoch+1) % 1000 == 0:
            print(
                'epoch %d, loss %.5e'
                % (epoch + 1, l))
        if epoch > 0:
            if (epoch+1) % 10000 == 0:
                a = loss[epoch, 0] / loss[epoch - 9999, 0]
                print(a)
                if 0.95< a <= 1:
                    break
train()
######################################save the trained model param ########################################################
W1 = model.hidden1.weight
b1 = model.hidden1.bias
W2 = model.hidden2.weight
b2 = model.hidden2.bias
W3 = model.predict.weight
b3 = model.predict.bias
W1.requires_grad_(requires_grad=False)
W2.requires_grad_(requires_grad=False)
W3.requires_grad_(requires_grad=False)
b1.requires_grad_(requires_grad=False)
b2.requires_grad_(requires_grad=False)
b3.requires_grad_(requires_grad=False)
W1_numpy = numpy.array(W1.cpu())
W2_numpy = numpy.array(W2.cpu())
W3_numpy = numpy.array(W3.cpu())
b1_numpy = numpy.array(b1.cpu())
b2_numpy = numpy.array(b2.cpu())
b3_numpy = numpy.array(b3.cpu())
PKU =1
model_path=file_container+'/model.pt'
torch.save(model,model_path)
W1_path=file_container+'/W1.txt'
exec(f'np.savetxt(W1_path, W1_numpy)')##
W2_path=file_container+'/W2.txt'
exec(f'np.savetxt(W2_path, W2_numpy)')
W3_path=file_container+'/W3.txt'
exec(f'np.savetxt(W3_path, W3_numpy)')
b1_path=file_container+'/b1.txt'
exec(f'np.savetxt(b1_path, b1_numpy)')
b2_path=file_container+'/b2.txt'
exec(f'np.savetxt(b2_path, b2_numpy)')
b3_path=file_container+'/b3.txt'
exec(f'np.savetxt(b3_path, b3_numpy)')
loss_path=file_container+'/loss.txt'
exec(f'np.savetxt(loss_path, loss)')
##############################################################################################
output = model(x_input)
##################### MinMax Denormalization ############################
y_nn = ((((output - (-1)) / (1 - (-1))) * (y_max - y_min) + y_min)).cpu().detach().numpy()
y_nn_path=file_container+'/y_nn.txt'
#y_nn_name="y_nn"+str(variableName_x)+str(variableName_y)
#print(y_nn_name)
exec(f'np.savetxt(y_nn_path, y_nn)')
x_input_path=file_container+'/x_input.txt'
exec(f'np.savetxt(x_input_path,x_input)')
## define the RMS_normal
def RMS_normal(net, target, num):
    a = (net - target)
    b = (a / target)
    c = torch.sum(b**2, dim=0)
    d = math.sqrt(c/num)
    e = d * 100
    return e
## Calculate the root mean square error（RMSE）
y_tensor = torch.from_numpy(Training_data[:, 1].reshape(Training_data.shape[0], 1))
moy_tensor = torch.from_numpy(y_nn)
R_RMS = RMS_normal(moy_tensor, y_tensor, 1000)
print('RMS %.5e'% (R_RMS))

plt.figure(1)
plt.scatter(x_input, y_array, c='none', marker='o', edgecolors='r')
plt.plot(x_input, y_nn, 'blue')
plt.ylabel('Ratio')
plt.xlabel('Vg')
plt.title('Ratio-Vg')
plt.savefig(file_container+'/Ratio-Vg.jpg', dpi=300)
plt.show()
