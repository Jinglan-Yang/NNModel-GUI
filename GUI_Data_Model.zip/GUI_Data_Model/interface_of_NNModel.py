import tkinter as tk
import numpy as np
from PIL import Image,ImageTk
#import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)
# Implement the default Matplotlib key bindings.
from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure
import os
from tkinter import ttk
import sys

#if getattr(sys, "frozen", False):
    #BASE_DIR = os.path.dirname(sys.executable)
#else:
    #BASE_DIR = os.path.dirname(os.path.abspath(__file__))

window=tk.Tk()

window.title('interface of NNModel')
sw = window.winfo_screenwidth()
sh = window.winfo_screenheight()
window.geometry('{}x{}'.format(sw,sh))

########
#label，button之类的大小和尺寸可能需要根据屏幕的尺寸再调节一下
#start_script_()里运行model_train.py目前使用的是os.popen(),之后可以看看有没有其他的方法
#导入model_train.py后，需要用户根据自身情况改变file_container，即model_train.py所在的路径文件夹
#使用save_script_()需要load_()设置file_container
#需要先点击Data按钮，保存plot data页面存在（可以最小化），再点击Train按钮，运行model.train.py，这样生成的y_nn才可以被plot data页面中的plot_Ynn使用
#######
def data_():
    global window_data,content,VALUE
    window_data=tk.Toplevel(window)
    window_data.geometry('{}x{}'.format(sw,sh))
    window_data.title('Plot data')

    data_loaded_confir=tk.StringVar()
    l1=tk.Label(window_data, textvariable=data_loaded_confir,bg='white',font=('Arial',12),width=100,height=2)
    l1.place(x=20,y=5)
    def load_():
        global content, variable_names, VALUE

        #用于画图的文件的路径
        Path1 = tk.filedialog.askopenfilename()
        print('\n获取的文件地址:', Path1)
        file = Path1
        handle=open(file,mode='r')

        #获取变量名（文件第一行）
        head=handle.readlines(1)
        handle.close()
        variable_names=head[0].split()
 
        #导入文件（跳过文件第一行）
        content=np.loadtxt(file,skiprows=1)

        data_loaded_confir.set('Load data successfully! File path: {}'.format(Path1))

        #设置x轴和y轴下拉框中的内容（变量名）
        VALUE=tuple(variable_names)
        com1["value"]=VALUE
        com2['value']=VALUE

        return content, variable_names

    b_load=tk.Button(window_data,text='Load Data',width=10,height=2,command=load_)
    b_load.place(x=5,y=5)

    # figure下拉框
    tk.Label(window_data,text="figure:").place(x=5,y=70)
    figVariable = tk.StringVar()
    com = ttk.Combobox(window_data,textvariable=figVariable) 
    com.place(x=5,y=90)
    com["value"] = ("1", "2", "3","4")
    def figFunc(event):
        #print(com.get())        
        print(figVariable.get())
    com.bind("<<ComboboxSelected>>", figFunc)

    # X-axis下拉框
    tk.Label(window_data,text="X-axis:").place(x=300,y=70)
    xVariable=tk.StringVar()
    xSecure=tk.StringVar()
    tk.Label(window_data,textvariable=xSecure).place(x=300,y=130)
    com1=ttk.Combobox(window_data,textvariable=xVariable)
    com1.place(x=300,y=90)
    com1["value"]=('None') #load用于画图之后的文件后，会添加变量名
    def xFunc(event):
        #print(com1.get())
        print(xVariable.get())
        xSecure.set("You have select X-axis as:"+xVariable.get())
    com1.bind("<<ComboboxSelected>>", xFunc)   

    # Y-axis下拉框
    tk.Label(window_data,text="Y-axis:").place(x=600,y=70)
    yVariable=tk.StringVar()
    ySecure=tk.StringVar()
    tk.Label(window_data,textvariable=ySecure).place(x=600,y=130)
    com2=ttk.Combobox(window_data,textvariable=yVariable)
    com2.place(x=600,y=90)
    com2["value"]=('None') #load用于画图之后的文件后，会添加变量名
    def yFunc(event):
        #print(com2.get())
        print(yVariable.get())
        ySecure.set("You have select Y-axis as:"+yVariable.get())
    com2.bind("<<ComboboxSelected>>", yFunc)  

    #画图
    def draw():
        x=content[:,VALUE.index(xVariable.get())]
        y=content[:,VALUE.index(yVariable.get())]
        if int(figVariable.get())==1:
            ax1.scatter(x,y, c='none', marker='o', edgecolors='r')
            canvas.draw()
        elif int(figVariable.get())==2:
            ax2.scatter(x,y, c='none', marker='o', edgecolors='r')
            canvas.draw()
        elif int(figVariable.get())==3:
            ax3.scatter(x,y, c='none', marker='o', edgecolors='r')
            canvas.draw()
        elif int(figVariable.get())==4:
            ax4.scatter(x,y, c='none', marker='o', edgecolors='r')
            canvas.draw()
    b_newplot=tk.Button(window_data,text='plot',width=10,height=2,command=draw)
    b_newplot.place(x=900,y=80)

    #画运行model_train.py所得到的y_nn
    def draw_Ynn():
        x=content_x_input[:]
        y=content_y_nn[:]
        if int(figVariable.get())==1:
            ax1.plot(x,y, 'blue')
            canvas.draw()
        elif int(figVariable.get())==2:
            ax2.plot(x,y, 'blue')
            canvas.draw()
        elif int(figVariable.get())==3:
            ax3.plot(x,y, 'blue')
            canvas.draw()
        elif int(figVariable.get())==4:
            ax4.plot(x,y, 'blue')
            canvas.draw()

    b_Ynn=tk.Button(window_data,text='plot_Ynn',width=10,height=2,command=draw_Ynn)
    b_Ynn.place(x=1200,y=80)

    #设置四幅图的位置和尺寸
    fig = Figure(figsize=(10, 6), dpi=90, layout='constrained')
    ax1 = fig.add_subplot(221)
    ax1.set_xlabel("x")
    ax1.set_ylabel("y")

    ax2 = fig.add_subplot(222)
    ax2.set_xlabel("x")
    ax2.set_ylabel("y")

    ax3 = fig.add_subplot(223)
    ax3.set_xlabel("x")
    ax3.set_ylabel("y")

    ax4 = fig.add_subplot(224)
    ax4.set_xlabel("x")
    ax4.set_ylabel("y")

    canvas = FigureCanvasTkAgg(fig, master=window_data)  # A tk.DrawingArea.
    canvas.draw()
    canvas.get_tk_widget().place(x=50,y=170)

b1=tk.Button(window,text='Data',width=15,height=2,command=data_)
b1.place(x=10,y=100)

script_path=tk.StringVar()
def train_():
    window_train=tk.Toplevel(window)
    window_train.geometry('{}x{}'.format(sw,sh))
    window_train.title('train data')

    #承接导入的model_train.py
    write_script=tk.Text(window_train,height=int(sh/16),width=int(sw/16),bg='#87CEEB',)
    write_script.place(x=0,y=50)

    #承接运行model_train.py得到的输出
    start_script=tk.Text(window_train,height=int(sh/16),width=int(sw/16),bg='#F08080')
    start_script.place(x=int(sw/2),y=50)


    def load_():
        global script_path, file_container

        #获取model_train.py的路径
        Path2 = tk.filedialog.askopenfilename()
        print('\n获取的文件地址:', Path2)

        #获取model_train.py所在文件夹的路径
        file_container=Path2[:Path2.rindex('/')]
        print('file container: ',file_container)

        #导入model_train.py
        file = Path2
        script_path.set(Path2)
        f = open(file,mode='r',encoding='utf-8')
        content=f.read()
        write_script.insert('insert',content)
        f.close()
        #print(write_script.get("1.0",'end-1c'))
        return Path2

    b_load_script=tk.Button(window_train,text='Load Script',width=10,height=2,command=load_)
    b_load_script.place(x=5,y=5)

    #保存粉色框中的内容于.py文件中
    def save_script_():
        window_save_script=tk.Toplevel(window)
        sw = window.winfo_screenwidth()
        sh = window.winfo_screenheight()
        ww=350
        wh=300
        x = (sw-ww) / 2
        y = (sh-wh) / 2
        window_save_script.geometry("%dx%d+%d+%d" %(ww,wh,x,y))
        window_save_script.title('Save script to Verilog-a file')

        path_name=tk.StringVar()
        tk.Label(window_save_script,text='Path:').place(x=10,y=50)
        entry_path_name=tk.Entry(window_save_script,textvariable=path_name)
        entry_path_name.place(x=100,y=50)

        file_name=tk.StringVar()
        tk.Label(window_save_script,text='File Name:').place(x=10,y=100)
        entry_file_name=tk.Entry(window_save_script,textvariable=file_name)
        entry_file_name.place(x=100,y=100)
        
        var2=tk.StringVar()
        #var2.set("successfully!")
        l2=tk.Label(window_save_script, textvariable=var2,bg='white',font=('Arial',12),width=20,height=2)
        l2.place(x=110,y=200)

        def save_():

            current_work_dir = os.path.dirname(__file__)
            print("current path:",current_work_dir)
            fileName=entry_file_name.get()+'.py'
            #保存在本文件夹中
            #file_handle=open(current_work_dir+'/'+fileName,mode='w')
            file_handle=open(path_name.get()+'/'+fileName,mode='w')
            file_handle.write(write_script.get("1.0",'end-1c'))
            var2.set('successfully!')
            file_handle.close()
            
       
        b_save=tk.Button(window_save_script,text='Save',width=15,height=2,command=save_)
        b_save.place(x=110,y=150)

    b_save_script=tk.Button(window_train,text='Save Script',width=10,height=2,command=save_script_)
    b_save_script.place(x=100,y=5)

    #run粉色框中的内容
    def start_script_():
        global content_y_nn,content_x_input
        file_handle=open(file_container+'/Script.py',mode='w',encoding='utf-8')
        #print(write_script.get("1.0",'end-1c'))
        screenContent=write_script.get("1.0",'end-1c')
        #print(screenContent)
        file_handle.write(screenContent)
        file_handle.close() 
        path_name=file_container+'/Script.py'
        result = os.popen(r'python {}'.format(path_name))
        a=result.read()
        start_script.insert('insert',a)
        print(type(a))
        file_y_nn=file_container+'/y_nn.txt'
        content_y_nn=np.loadtxt(file_y_nn)
        file_x_input=file_container+'/x_input.txt'
        content_x_input=np.loadtxt(file_x_input)
        result.close()

        

    b_start_script=tk.Button(window_train,text='Start train',width=10,height=2,command=start_script_)
    b_start_script.place(x=200,y=5)


b2=tk.Button(window,text='Train',width=15,height=2,command=train_)
b2.place(x=10,y=200)

window.mainloop()