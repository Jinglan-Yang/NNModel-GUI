##*******************************************************************//
##*            PKU PHIMO-ANN model (Training/model_framework)       *//
##*******************************************************************//

## ******************************************************************//
## * Copyright 2023 Peking University, Shenhen. All rights reserved  //
## *               
## * Project Director: Prof. Lining Zhang                            //
## * Authors: Wu Dai, Yu Li.//
## * Notes: This version is used to show the fitting ability of NN model.     //
## * The target is y = 2*sin(x) + 1                                 //
## *****************************************************************//
import torch
import torch.nn as nn

num_inputs, num_outputs, num_1_hiddens, num_2_hiddens= 1, 1, 10, 10

class MLPregression(nn.Module):
    def __init__(self):
        super(MLPregression,self).__init__()
        #First layer, 1st Hidden layer
        # self.hidden1=nn.Linear(in_features=num_inputs, out_features=num_1_hiddens, bias=True).cuda()
        self.hidden1=nn.Linear(in_features=num_inputs, out_features=num_1_hiddens, bias=True)
        #Second layer, 2nd Hidden layer
        # self.hidden2=nn.Linear(num_1_hiddens,num_2_hiddens).cuda()
        self.hidden2=nn.Linear(num_1_hiddens,num_2_hiddens)
        #Third layer, Output layer
        # self.predict=nn.Linear(num_2_hiddens,num_outputs).cuda()
        self.predict=nn.Linear(num_2_hiddens,num_outputs)
    #Forward
    def forward(self,x):
        tmp = x[:, 0].reshape(x.shape[0], 1)
        # x_input = torch.from_numpy(tmp).cuda().to(torch.float32).requires_grad_(requires_grad=True)
        x_input = torch.from_numpy(tmp).to(torch.float32).requires_grad_(requires_grad=True)
        ###################  MinMax Normalization  #############################################################
        x_input_train = ((x_input - (-1.570796326794896558e+01)) / (1.570796326794896558e+01 - (-1.570796326794896558e+01))) * 2 - 1
        x = x_input_train.to(torch.float32).requires_grad_(requires_grad=True)
        #Activation function of hidden layer
        # x=torch.sigmoid(self.hidden1(x)).cuda()
        # x=torch.sigmoid(self.hidden2(x)).cuda()
        x=torch.sigmoid(self.hidden1(x))
        x=torch.sigmoid(self.hidden2(x))
        output=self.predict(x)
        return output

